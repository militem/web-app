//RUTA DE LA API
const express = require('express');
const router = express.Router();

const mysqlConnection = require('../database');

router.post('/api/articles/', (req, res) => {
    const { num_registros, lim_min } = req.body;
    mysqlConnection.query('SELECT id_article, title, img_front, category, category_url, description, text, tags, link, pdf, Date_format(date, "%d-%m-%Y") AS date, autor FROM articles ORDER BY articles.date DESC LIMIT ? OFFSET ?', [num_registros, lim_min], (err, rows, fields) => {
        if (!err) {
            result = {
                msg: 'OK',
                rows: rows
            }
            res.json(result);
        } else {
            result = {
                msg: 'error'
            }
            res.json(result);
            console.log(err);
        }
    });
});

router.post('/api/searchAndNextArticle/', (req, res) => {
    const { num_registros, lim_min, busqueda } = req.body;
    mysqlConnection.query('SELECT id_article, title, img_front, category, category_url, description, text, tags, link, pdf, Date_format(date, "%d-%m-%Y") AS date, autor FROM articles WHERE title LIKE ?"%" ORDER BY articles.date DESC LIMIT ? OFFSET ?', [busqueda, num_registros, lim_min], (err, rows, fields) => {
        if (!err) {
            result = {
                msg: 'OK',
                rows: rows
            }
            res.json(result);
        } else {
            result = {
                msg: 'error'
            }
            res.json(result);
            console.log(err);
        }
    });
});

router.post('/api/getArticle/', (req, res) => {
    const { busqueda } = req.body;
    mysqlConnection.query('SELECT id_article, title, img_front, category, category_url, description, text, tags, link, pdf, Date_format(date, "%d-%m-%Y") AS date, autor FROM articles WHERE link = ?', [busqueda], (err, rows, fields) => {
        if (!err) {
            result = {
                msg: 'OK',
                rows: rows
            }
            res.json(result);
        } else {
            result = {
                msg: 'error'
            }
            res.json(result);
            console.log(err);
        }
    });
});

router.get('/api/categories/', (req, res) => {
    mysqlConnection.query('SELECT * FROM categories', (err, rows, fields) => {
        if (!err) {
            result = {
                msg: 'OK',
                rows: rows
            }
            res.json(result);
        } else {
            result = {
                msg: 'error'
            }
            res.json(result);
            console.log(err);
        }
    });
});

router.post('/api/getCategory/', (req, res) => {
    const { busqueda } = req.body;
    mysqlConnection.query('SELECT * FROM articles WHERE category = ?', [busqueda], (err, rows, fields) => {
        if (!err) {
            result = {
                msg: 'OK',
                rows: rows
            }
            res.json(result);
        } else {
            result = {
                msg: 'error'
            }
            res.json(result);
            console.log(err);
        }
    });
});

module.exports = router;