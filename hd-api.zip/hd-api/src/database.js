//Conexión a la base de datos
const mysql = require('mysql');
const mysqlConnection = mysql.createConnection({
    host: '147.182.199.84',
    user: 'hdrm',
    password: 'TyBe64$.2',
    database: 'hdsec'
});

mysqlConnection.connect((err) => {
    if (err) {
        console.log(err);
        return;
    } else {
        console.log('Db is connected');
    }
})

module.exports = mysqlConnection;